<?php

$category = $_POST['category'];

$category_exits = 0;

$pagename = $category . ".html";

$path = "projects/categories/$category/$pagename";

$path_post = "projects/files/$pagename";

$path_chat = "projects/chat/categories/$category/$pagename";

if(file_exists($path)){
    echo "Category found <a href='$path' target='_blank'>$category</a><br>";
    $category_exits = 1;
}

if(file_exists($path_post)){
    echo "Post found <a href='$path_post' target='_blank'>$category</a><br>";
    $category_exits = 1;
}

if(file_exists($path_chat)){
    echo "Chat found <a href='$path_chat' target='_blank'>$category</a><br>";
    $category_exits = 1;
}

if ($category_exits == 0){
   echo "Sorry, this category does not exist.<br>";
}

?>
<br>
<a href="index.html">Back</a>
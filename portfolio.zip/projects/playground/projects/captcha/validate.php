<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Validation Result</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
    }

    h1 {
      color: #333;
    }

    .success {
      color: #4caf50;
    }

    .error {
      color: #f44336;
    }
  </style>
</head>

<body>

<?php
session_start();

if ($_SESSION['captcha'] == $_POST['captcha']) {
    echo "<h1 class='success'>OK - Correct Code</h1>";
} else {
    echo "<h1 class='error'>Error - Incorrect Code Entered</h1>";
}
?>

</body>

</html>

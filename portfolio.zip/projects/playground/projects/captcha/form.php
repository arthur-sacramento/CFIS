<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Captcha</title>
  <style>
    body {
      font-family: Arial, sans-serif;
    }

    form {
      max-width: 300px;
      margin: 0 auto;
      text-align: center;
    }

    img {
      margin-bottom: 10px;
    }

    label {
      display: block;
      margin-bottom: 5px;
    }

    input[type="text"] {
      width: 100%;
      padding: 8px;
      margin-bottom: 10px;
      box-sizing: border-box;
    }

    input[type="submit"] {
      background-color: #4caf50;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #45a049;
    }
  </style>
</head>

<body>

  <form method="post" action="validate.php">
    <img src="captcha.php" alt="captcha code" />
    <br />
    <label for="captcha">Enter the code</label>
    <input type="text" name="captcha" id="captcha" />
    <br />
    <input type="submit" value="Submit" />
  </form>

</body>

</html>

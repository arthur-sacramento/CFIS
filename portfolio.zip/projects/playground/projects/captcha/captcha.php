<?php
session_start();

// Generate a random captcha code
$captchaCode = substr(md5(time()), 0, 9);

// Store the captcha code in the session
$_SESSION['captcha'] = $captchaCode;

// Create an image with a background
$captchaImage = imagecreatefrompng("backgroundcaptcha.png");

// Load a font for the captcha text
$captchaFont = imageloadfont("anonymous.gdf");

// Set the color for the captcha text
$captchaColor = imagecolorallocate($captchaImage, 255, 0, 0);

// Add the captcha text to the image
imagestring($captchaImage, $captchaFont, 15, 5, $captchaCode, $captchaColor);

// Set the content type header to display the image
header("Content-type: image/png");

// Output the image as PNG
imagepng($captchaImage);

// Free up memory by destroying the image resource
imagedestroy($captchaImage);
?>
